<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <?php
                  $category_name=$coaching_cat_id="";  
                  if($category)
                  {
                    $coaching_cat_id=$category->id;
                    $category_name=$category->category_name;
                    
                  }
                ?>
                <div class="card">
                  <div class="card-body">
                    <a href="<?php echo e(route('admin.coachingCategoryList')); ?>" class="btn btn-outline-info btn-fw" style="float: right;">Coaching Category List</a>
                    <h4 class="card-title">Coaching Category Management</h4>
                    <p class="card-description"> Add / Update Coaching Category </p>
                    <form class="forms-sample" method="post" action="<?php echo e(route('admin.addCoachingCategory')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                      <div class="row">
                        <div class="form-group col-md-6">
                          <input type="hidden" name="id" value="<?php echo e($coaching_cat_id); ?>">
                          <label for="exampleInputUsername1">Category Name</label>
                          <input type="text" class="form-control form-control-sm" placeholder="Enter category name"  name="category_name" value="<?php echo e($category_name); ?>" required>
                        </div>                        
                      </div>
                      <button type="submit" class="btn btn-primary me-2">Submit</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
        </div>
        <!-- main-panel ends -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
       
        <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/demovotive/public_html/coachsparkle/resources/views/admin/add_coaching_category.blade.php ENDPATH**/ ?>