<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <?php
                    $first_name=$last_name=$email=$gender=$user_id=$short_bio=$professional_title=$detailed_bio="";
                    
                    $country_name=$state_name=$city_name=$profile_image='';
                    if($user_detail)
                    {
                       $user_id=$user_detail->user_id;
                      $first_name=$user_detail->user_first_name;
                      $last_name=$user_detail->user_last_name;
                      $email=$user_detail->user_email;
                      $gender=$user_detail->user_gender;
                      $short_bio=$user_detail->user_short_bio;
                      $professional_title=$user_detail->user_professional_title;
                      $detailed_bio=$user_detail->user_detailed_bio;
                      $country_name=$user_detail->country_name;
                      $state_name=$user_detail->state_name;
                      $city_name=$user_detail->city_name;
                    
                      $profile_image=$user_detail->user_profile_image;
                    }
                    
                  ?>

   <div class="container mt-4">
     <a href="<?php echo e(route('admin.enquiryList')); ?>" class="btn btn-outline-info btn-sm btn-fw" style="float: right;">Enquiry List</a>

                   <div class="row">
  
                      <div class="col-md-12">
                       <div class="card">
                         <div class="card-body">
                           <h5 class="card-title">Users Details</h5>
                            <div class="row">
                            <div class="form-group col-md-6">
                              <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                              <label for="exampleInputUsername1"><strong>First Name : </strong> <?php echo e($first_name); ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1"><strong>Last Name : </strong><?php echo e($last_name); ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Email address : </strong><?php echo e($email); ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Gender : </strong> <?php echo e($gender==1?'Male':($gender==2?'Female':'')); ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Country : </strong> <?php echo e($country_name); ?></label>
                              
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>State : </strong> <?php echo e($state_name); ?></label>
                              
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>City : </strong> <?php echo e($city_name); ?></label>
                              
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Short Bio : </strong> <?php echo e($short_bio); ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Professional Title : </strong> <?php echo e($professional_title); ?></label>
                            </div>
                          
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Profile Image  : </strong></label>
                            <img src="<?php echo e(!empty($user_detail->user_profile_image) ? url('public/uploads/profile_image/' . $user_detail->user_profile_image) : ''); ?>" style="max-width: 200px; max-height: 200px;">

                              
                            </div>
                          </div>
                     </div>
                </div>
           </div>

    <!-- Card 2 -->
             <div class="col-md-12 mt-3">
                <div class="card">
                   <div class="card-body">
                      <h5 class="card-title">Coach Details</h5>
                         <div class="row">
                            <div class="form-group col-md-6">
                              <input type="hidden" name="user_id" value="<?php if(!empty($coach_detail)): ?><?php echo e($coach_detail->id); ?><?php endif; ?>">
                              <label for="exampleInputUsername1"><strong>First Name : </strong><?php if(!empty($coach_detail)): ?><?php echo e($coach_detail->coach_first_name); ?><?php endif; ?> </label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1"><strong>Last Name : </strong><?php if(!empty($coach_detail)): ?><?php echo e($coach_detail->coach_last_name); ?><?php endif; ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Email address : </strong><?php if(!empty($coach_detail)): ?><?php echo e($coach_detail->coach_email); ?><?php endif; ?></label>
                            </div>
                            
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Gender : </strong> <?php if(!empty($coach_detail->coach_gender)): ?><?php echo e($coach_detail->coach_gender==1?'Male':($coach_detail->coach_gender==2?'Female':'Other')); ?><?php endif; ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Country : </strong> <?php if(!empty($coach_detail)): ?><?php echo e($coach_detail->country_name); ?><?php endif; ?></label>
                              
                            </div>
                            <div class="form-group col-md-6">
                           <label for="exampleInputEmail1"><strong>State : </strong>
                           <?php if(!empty($coach_detail) && $coach_detail->state_name): ?>
                           <?php echo e($coach_detail->state_name); ?>

                             <?php endif; ?>
                          </label>
                            </div>
                            <div class="form-group col-md-6">
                           <label for="exampleInputEmail1"><strong>City : </strong> <?php if(!empty($coach_detail) && $coach_detail->state_name): ?>
                           <?php echo e($coach_detail->city_name); ?>

                             <?php endif; ?>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Short Bio : </strong> <?php if(!empty($coach_detail) && $coach_detail->coach_short_bio): ?>
                           <?php echo e($coach_detail->coach_short_bio); ?>

                             <?php endif; ?>
                           </label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Professional Title : </strong> 
                                <?php if(!empty($coach_detail) && $coach_detail->coach_professional_title): ?>
                               <?php echo e($coach_detail->coach_professional_title); ?>

                               <?php endif; ?>
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1"><strong>Profile Image  : </strong></label>
                              <?php if(!empty($coach_detail->coach_profile_image)): ?>
                              <img src="<?php echo e(url('public/uploads/profile_image/' . $coach_detail->coach_profile_image)); ?>" style="max-width: 200px;max-height: 200px;">
                              <?php endif; ?>
                              
                            </div>
                          </div>
                      </div>
                   </div>
                 </div>

    <!-- Card 3 -->
                <div class="col-md-12 mt-3">
                  <div class="card">
                    <div class="card-body">
                       <h5 class="card-title">Enquiry Details</h5>
                         <div class="row">
                            <div class="form-group col-md-6">
                              <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                              <label for="exampleInputUsername1"><strong>Enquiry Title : </strong> <?php if(!empty($enquiry_detail)): ?><?php echo e($enquiry_detail->enquiry_title); ?><?php endif; ?></label>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1"><strong>Enquiry Detail : </strong><?php if(!empty($enquiry_detail)): ?><?php echo e($enquiry_detail->enquiry_detail); ?><?php endif; ?></label>
                            </div>
                            </div>
                          </div>
                       </div>
                      </div>
                    </div>
                 </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
        </div>
        <!-- main-panel ends -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
          <script>
            var triggerTabList = [].slice.call(document.querySelectorAll('#myTab a'))
            triggerTabList.forEach(function (triggerEl) {
              var tabTrigger = new bootstrap.Tab(triggerEl)

              triggerEl.addEventListener('click', function (event) {
                event.preventDefault()
                tabTrigger.show()
              })
            })
          </script>
        <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/demovotive/public_html/coachsparkle/resources/views/admin/view_enquiry_profile.blade.php ENDPATH**/ ?>