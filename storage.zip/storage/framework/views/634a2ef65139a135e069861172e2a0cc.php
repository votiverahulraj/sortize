<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <?php
                    $first_name=$last_name=$email=$gender=$user_id=$short_bio=$professional_title=$detailed_bio="";
                    $country_id=$state_id=$city_id=0;
                    if($user_detail)
                    {
                      $user_id=$user_detail->id;
                      $first_name=$user_detail->first_name;
                      $last_name=$user_detail->last_name;
                      $email=$user_detail->email;
                      $gender=$user_detail->gender;
                      $country_id=$user_detail->country_id;
                      $state_id=$user_detail->state_id;
                      $city_id=$user_detail->city_id;
                      $short_bio=$user_detail->short_bio;
                      $professional_title=$user_detail->professional_title;
                      $detailed_bio=$user_detail->detailed_bio;
                    }
                    $video_link=$experience=$coaching_category=$delivery_mode=$free_trial_session=$is_volunteered_coach="";
                    $volunteer_coaching=$website_link=$objective=$coach_type=$coach_subtype="";
                    $price=0;
                    if($profession)
                    {
                      $video_link=$profession->video_link;
                      $experience=$profession->experience;
                      $coaching_category=$profession->coaching_category;
                      $delivery_mode=$profession->delivery_mode;
                      $free_trial_session=$profession->free_trial_session;
                      $price=$profession->price;
                      $is_volunteered_coach=$profession->is_volunteered_coach;
                      $volunteer_coaching=$profession->volunteer_coaching;
                      $website_link=$profession->website_link;
                      $objective=$profession->objective;
                      $coach_type=$profession->coach_type;
                      $coach_subtype=$profession->coach_subtype;
                    }
                  ?>
                <div class="card">
                  <div class="card-body">
                      <a href="<?php echo e(route('admin.coachList')); ?>" class="btn btn-outline-info btn-fw" style="float: right;">Coach List</a>
                      <h4 class="card-title">Coach Management</h4>
                      <!--p class="card-description"> Add / Update Blog  </p-->

                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Basic Profile</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false" <?php echo e($user_id==''?'disabled':''); ?>>Professional Profile</button>
                      </li>
                      <!--li class="nav-item" role="presentation">
                        <button class="nav-link" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button" role="tab" aria-controls="messages" aria-selected="false">Messages</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab" aria-controls="settings" aria-selected="false">Settings</button>
                      </li-->
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                      <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
                      <form class="forms-sample" method="post" action="<?php echo e(route('admin.addCoach')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                          <div class="row">
                            <div class="form-group col-md-6">
                              <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                              <label for="exampleInputUsername1">First Name</label>
                              <input required type="text" class="form-control form-control-sm" placeholder="First Name" aria-label="Username" name="first_name" value="<?php echo e($first_name); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1">Last Name</label>
                              <input required type="text" class="form-control form-control-sm" placeholder="Last Name" aria-label="Username" name="last_name" value="<?php echo e($last_name); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Email address</label>
                              <input required type="email" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Email" name="email" value="<?php echo e($email); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Password</label>
                              <input type="password" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Password" name="password">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Coach Type</label>
                              <select class="form-select form-select-sm" id="coach_type" name="coach_type">
                                <option>Select Coach Type</option>  
                                  <?php if($type): ?>
                                  <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($types->id); ?>" <?php echo e($coach_type==$types->id?'selected':''); ?>><?php echo e($types->type_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Coach SubType</label>
                              <select class="form-select form-select-sm" id="coach_subtype" name="coach_subtype">
                                <?php if($subtype): ?>
                                <?php $__currentLoopData = $subtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtypes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($subtypes->id); ?>" <?php echo e($coach_subtype==$subtypes->id?'selected':''); ?>><?php echo e($subtypes->subtype_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Gender</label>
                              <select required class="form-select form-select-sm" id="exampleFormControlSelect3" name="gender">
                                <option value="1" <?php echo e($gender==1?'selected':''); ?>>Male</option>
                                <option value="2" <?php echo e($gender==2?'selected':''); ?>>Female</option>
                                <option value="3" <?php echo e($gender==3?'selected':''); ?>>Other</option>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Country</label>
                              <select required class="form-select form-select-sm" id="country" name="country_id">
                                <option>Select Country</option>  
                                <?php if($country): ?>
                                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($country->country_id); ?>" <?php echo e($country_id==$country->country_id?'selected':''); ?>><?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">State</label>
                              <select required class="form-select form-select-sm" id="state" name="state_id">
                                <option>Select State</option>
                                <?php if($state): ?>
                                <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($states->state_id); ?>" <?php echo e($state_id==$states->state_id?'selected':''); ?>><?php echo e($states->state_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">City</label>
                              <select required class="form-select form-select-sm" id="city" name="city_id">
                                <option>Select City</option>
                                <?php if($city): ?>
                                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cities->city_id); ?>" <?php echo e($city_id==$cities->city_id?'selected':''); ?>><?php echo e($cities->city_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Short Bio</label>
                              <textarea required class="form-control form-control-sm" name="short_bio" maxlength="300" id="short_bio"><?php echo e($short_bio); ?></textarea>
                              <small id="bioCounter">300 characters remaining</small>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Professional Title</label>
                              <input required type="text" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Professional Title" name="professional_title" value="<?php echo e($professional_title); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Coaching Category</label>
                              <select required class="form-select form-select-sm" id="exampleFormControlSelect3" name="coaching_category">
                                <?php if($category): ?>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categ->id); ?>" <?php echo e($coaching_category==$categ->id?'selected':''); ?>><?php echo e($categ->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Delivery Mode</label>
                              <select required class="form-select form-select-sm" id="exampleFormControlSelect3" name="delivery_mode">
                                <?php if($mode): ?>
                                <?php $__currentLoopData = $mode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($modes->id); ?>" <?php echo e($delivery_mode==$modes->id?'selected':''); ?>><?php echo e($modes->mode_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Service Offered</label>
                              <select required class="js-example-basic-multiple w-100" multiple="multiple" name="service_offered[]">
                                <?php if($service): ?>
                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($services->id); ?>" <?php echo e(in_array($services->id, $selectedServiceIds) ? 'selected' : ''); ?>><?php echo e($services->service); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Language</label>
                              <select required class="js-example-basic-multiple w-100" multiple="multiple" name="language[]">
                                <?php if($language): ?>
                                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $languages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($languages->id); ?>" <?php echo e(in_array($languages->id, $selectedLanguageIds) ? 'selected' : ''); ?>><?php echo e($languages->language); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Free Trial Session</label>
                              <select required class="form-select form-select-sm" id="exampleFormControlSelect3" name="free_trial_session">
                                <option value="1" <?php echo e($free_trial_session==1?'selected':''); ?>>Yes</option>
                                <option value="2" <?php echo e($free_trial_session==2?'selected':''); ?>>No</option>
                              </select>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Is Volunteered Coach</label>
                              <select  class="form-select form-select-sm" id="exampleFormControlSelect3" name="is_volunteered_coach">
                                <option value="1" <?php echo e($is_volunteered_coach==1?'selected':''); ?>>Yes</option>
                                <option value="2" <?php echo e($is_volunteered_coach==2?'selected':''); ?>>No</option>
                              </select>
                            </div>
                            <div class="form-group col-md-6" id="vol_coach">
                              <label for="exampleInputEmail1">Area of volunteer coaching session</label>
                              <input  type="text" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Area of volunteer coaching session" name="volunteer_coaching" value="<?php echo e($volunteer_coaching); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Profile Image</label>
                              <input  type="file" class="form-control form-control-sm" id="exampleInputEmail1" name="profile_image" accept="image/png, image/gif, image/jpeg">
                            </div>
                          </div>
                          <input type="hidden" name="user_time" value="" id="user_timezone">
                          <button type="submit" class="btn btn-primary me-2">Submit</button>
                        </form>
                      </div>
                      
                      <!--Coach Professional Profile-->
                      <div class="tab-pane" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <form class="forms-sample" method="post" action="<?php echo e(route('admin.addProfessional')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                          <div class="row">
                            <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1">Experiance(In year)</label>
                              <input type="text" class="form-control form-control-sm" placeholder="Experiance(In year)" maxlength="2" name="experiance" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="<?php echo e($experience); ?>">
                            </div>
                            
                            <div class="form-group col-md-6">
                              <label for="exampleInputUsername1">Price($)</label>
                              <div class="input-group">
                                <div class="input-group-prepend">
                                  <span class="input-group-text bg-primary text-white">$</span>
                                </div>
                                <input type="text" class="form-control form-control-sm" placeholder="price($)" maxlength="5" name="price" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="<?php echo e($price); ?>">
                              </div>
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Video Introduction</label>
                              <input type="text" class="form-control form-control-sm" id="video-introduction" placeholder="Video Introduction" pattern="https?://.+" name="video_introduction" value="<?php echo e($video_link); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Website</label>
                              <input type="text" class="form-control form-control-sm" id="Website" placeholder="Website" pattern="https?://.+" name="website" value="<?php echo e($website_link); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Objective of Coaching/Learning</label>
                              <input type="text" class="form-control form-control-sm" id="objective" placeholder="Objective of Coaching/Learning" name="objective" value="<?php echo e($objective); ?>">
                            </div>
                            <div class="form-group col-md-6">
                              <label for="exampleInputEmail1">Detailed Bio</label>
                              <textarea class="form-control form-control-sm" name="detailed_bio" maxlength="1000" id="detailed_bio"><?php echo e($detailed_bio); ?></textarea>
                              <small id="bioCounterDetail">1000 characters remaining</small>
                            </div>
                          </div>
                          <div id="documentContainer">
                            <?php $i=1; ?>  
                            <?php if($document): ?>
                            <?php $__currentLoopData = $document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row document-group">
                              <div class="form-group col-md-5">
                                <label>Document</label>
                                <input type="hidden" name="doc_id[]" value="<?php echo e($documents->id); ?>">
                                <input type="file" class="form-control form-control-sm document-input" name="document_file[]" accept="application/pdf">
                                <?php if(!empty($documents->document_file)): ?>
                                  <div class="mt-1 uploaded-file">
                                    <a href="<?php echo e(asset('/public/uploads/documents/' . $documents->document_file)); ?>" target="_blank"><?php echo e($documents->original_name); ?></a>
                                  </div>
                                <?php endif; ?>
                              </div>
                              <div class="form-group col-md-5">
                                <label>Document Type</label>
                                <select class="form-select form-select-sm" name="document_type[]">
                                  <option value="1" <?php echo e($documents->document_type == 1 ? 'selected' : ''); ?>>Certificate</option>
                                  <option value="2" <?php echo e($documents->document_type == 2 ? 'selected' : ''); ?>>CV</option>
                                  <option value="3" <?php echo e($documents->document_type == 3 ? 'selected' : ''); ?>>Brochure</option>
                                </select>
                              </div>
                              <div class="form-group col-md-2 d-flex align-items-end">
                                <button type="button" class="btn btn-outline-danger btn-rounded btn-icon remove-document" file_id="<?php echo e($documents->id); ?>">
                                  <i class="mdi mdi-minus text-dark"></i>
                                </button>
                              </div>
                            </div>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($i<5): ?>
                            <div class="row document-group">
                              <div class="form-group col-md-5">
                                <label>Document</label>
                                <input type="file" class="form-control form-control-sm document-input" name="document_file[]" accept="application/pdf">
                              </div>
                              <div class="form-group col-md-5">
                                <label>Document Type</label>
                                <select class="form-select form-select-sm" name="document_type[]">
                                  <option value="1">Certificate</option>
                                  <option value="2">CV</option>
                                  <option value="3">Brochure</option>
                                </select>
                              </div>
                              <div class="form-group col-md-2 d-flex align-items-end">
                                <button type="button" class="btn btn-outline-secondary btn-rounded btn-icon" id="addMoreDocuments">
                                  <i class="mdi mdi-plus text-dark"></i>
                                </button>
                              </div>
                            </div>
                            <?php endif; ?>
                          </div>
                          <button type="submit" class="btn btn-primary me-2">Submit</button>
                        </form>
                      </div>
                      <div class="tab-pane" id="messages" role="tabpanel" aria-labelledby="messages-tab">Thired</div>
                      <div class="tab-pane" id="settings" role="tabpanel" aria-labelledby="settings-tab">Fourth</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
        </div>
        <!-- main-panel ends -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
       <script>
        var triggerTabList = [].slice.call(document.querySelectorAll('#myTab a'))
        triggerTabList.forEach(function (triggerEl) {
          var tabTrigger = new bootstrap.Tab(triggerEl)

          triggerEl.addEventListener('click', function (event) {
            event.preventDefault()
            tabTrigger.show()
          })
        })
       </script>
       <script>
          document.addEventListener("DOMContentLoaded", function () {
              const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
              document.getElementById("user_timezone").value = userTimezone;
          });
          $(document).ready(function () {
            $(document).on('change', '#country', function () {
              var cid = this.value;   //let cid = $(this).val(); we cal also write this.
              $.ajax({
                url: "<?php echo e(url('/admin/getstate')); ?>",
                type: "POST",
                datatype: "json",
                data: {
                  country_id: cid,
                  '_token':'<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                  $('#state').html('<option value="">Select State</option>');
                  $.each(result.state, function(key, value) {
                    $('#state').append('<option value="' +value.state_id+ '">' +value.state_name+ '</option>');
                  });
                },
                errror: function(xhr) {
                    console.log(xhr.responseText);
                  }
                });
            });

            $('#state').change(function () {
              var sid = this.value;
              $.ajax({
                url: "<?php echo e(url('/admin/getcity')); ?>",
                type: "POST",
                datatype: "json",
                data: {
                  state_id: sid,
                  '_token':'<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                  console.log(result);
                  $('#city').html('<option value="">Select City</option>');
                  $.each(result.city, function(key, value) {
                    $('#city').append('<option value="' +value.city_id+ '">' +value.city_name+ '</option>')
                  });
                },
                errror: function(xhr) {
                    console.log(xhr.responseText);
                  }
              });
            });

            $('#coach_type').change(function () {
              var sid = this.value;
              $.ajax({
                url: "<?php echo e(url('/admin/getsubType')); ?>",
                type: "POST",
                datatype: "json",
                data: {
                  coach_type_id: sid,
                  '_token':'<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                  console.log(result);
                  $('#coach_subtype').html('<option value="">Select SubType</option>');
                  $.each(result.city, function(key, value) {
                    $('#coach_subtype').append('<option value="' +value.id+ '">' +value.subtype_name+ '</option>')
                  });
                },
                errror: function(xhr) {
                    console.log(xhr.responseText);
                  }
              });
            });
          });
        </script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const bio = document.getElementById('short_bio');
                const counter = document.getElementById('bioCounter');
                const max = 300;

                function updateCounter() {
                    const remaining = max - bio.value.length;
                    counter.textContent = `${remaining} characters remaining`;
                }

                bio.addEventListener('input', updateCounter);
                updateCounter(); // initial update
            });
        </script>
        <script>
          document.addEventListener('DOMContentLoaded', function () {
              const select = document.querySelector('select[name="is_volunteered_coach"]');
              const volCoachDiv = document.getElementById('vol_coach');

              function toggleVolCoach() {
                  if (select.value === '1') {
                      volCoachDiv.style.display = 'block';
                  } else {
                      volCoachDiv.style.display = 'none';
                  }
              }

              // Run on page load
              toggleVolCoach();

              // Run when the select changes
              select.addEventListener('change', toggleVolCoach);
          });
      </script>
      <script>
            document.addEventListener('DOMContentLoaded', function () {
                const biod = document.getElementById('detailed_bio');
                const counterd = document.getElementById('bioCounterDetail');
                const max = 1000;

                function updateCounterd() {
                    const remaining = max - biod.value.length;
                    counterd.textContent = `${remaining} characters remaining`;
                }

                biod.addEventListener('input', updateCounterd);
                updateCounterd(); // initial update
            });
        </script>
        <script>
          $(document).on('click', '#addMoreDocuments', function () {
            // Limit to 5 document upload fields
            if ($('#documentContainer .document-group').length >= 5) {
              alert("You can only upload up to 5 documents.");
              return;
            }

            const newRow = `
              <div class="row document-group mb-2">
                <div class="form-group col-md-5">
                  <label>Document</label>
                  <input type="file" name="document_file[]" class="form-control form-control-sm document-input" accept="application/pdf">
                </div>
                <div class="form-group col-md-5">
                  <label>Document Type</label>
                  <select name="document_type[]" class="form-select form-select-sm">
                    <option value="1">Certificate</option>
                    <option value="2">CV</option>
                    <option value="3">Brochure</option>
                  </select>
                </div>
                <div class="form-group col-md-2 d-flex align-items-end">
                  <button type="button" class="btn btn-outline-danger btn-rounded btn-icon remove-document">
                    <i class="mdi mdi-minus text-dark"></i>
                  </button>
                </div>
              </div>`;
            $('#documentContainer').append(newRow);
          });

          $(document).on('click', '.remove-document', function () {
            const fileId = $(this).attr('file_id');
            const row = $(this).closest('.document-group');

            if (fileId) {
              // Optional: Confirm deletion
              if (!confirm("Are you sure you want to delete this file?")) return;

              $.ajax({
                url: "<?php echo e(url('/admin/deleteDocument')); ?>",
                type: 'POST',
                data: {
                  '_token':'<?php echo e(csrf_token()); ?>',
                  id: fileId
                },
                success: function (response) {
                  if (response.success) {
                    row.remove();
                  } else {
                    alert("Error deleting document.");
                  }
                },
                error: function () {
                  alert("Failed to communicate with the server.");
                }
              });
            } else {
              // Just remove the row if there's no file_id
              row.remove();
            }
          });

        </script>
        <script>
          $(document).on('change', '.document-input', function () {
            const file = this.files[0];
            const parent = $(this).closest('.form-group');
            
            parent.find('.uploaded-file').remove();
            parent.find('.new-upload-preview').remove();

            if (file && file.type === 'application/pdf') {
              const fileName = file.name;
              const objectUrl = URL.createObjectURL(file); // temp file URL for preview

              const preview = `<div class="mt-1 new-upload-preview">
                                <a href="${objectUrl}" target="_blank">${fileName}</a>
                              </div>`;
              parent.append(preview);
            }
          });
        </script> 
        <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/demovotive/public_html/coachsparkle/resources/views/admin/coach_profile.blade.php ENDPATH**/ ?>