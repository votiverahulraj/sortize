<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <?php
                  $first_name=$last_name=$email=$gender=$user_id="";
                  $country_id=$state_id=$city_id=0;
                  if($user_detail)
                  {
                    $user_id=$user_detail->id;
                    $first_name=$user_detail->first_name;
                    $last_name=$user_detail->last_name;
                    $email=$user_detail->email;
                    $gender=$user_detail->gender;
                    $country_id=$user_detail->country_id;
                    $state_id=$user_detail->state_id;
                    $city_id=$user_detail->city_id;
                  }
                ?>
                <div class="card">
                  <div class="card-body">
                    <a href="<?php echo e(route('admin.userList')); ?>" class="btn btn-outline-info btn-fw" style="float: right;">User List</a>
                    <h4 class="card-title">User Management</h4>
                    <p class="card-description"> Add / Update user  </p>
                    <form class="forms-sample" method="post" action="<?php echo e(route('admin.addUser')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                      <div class="row">
                        <div class="form-group col-md-6">
                          <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                          <label for="exampleInputUsername1">First Name</label>
                          <input required type="text" class="form-control form-control-sm" placeholder="First Name" aria-label="Username" name="first_name" value="<?php echo e($first_name); ?>">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputUsername1">Last Name</label>
                          <input required type="text" class="form-control form-control-sm" placeholder="Last Name" aria-label="Username" name="last_name" value="<?php echo e($last_name); ?>">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">Email address</label>
                          <input required type="email" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Email" name="email" value="<?php echo e($email); ?>">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">Password</label>
                          <input type="password" class="form-control form-control-sm" id="exampleInputEmail1" placeholder="Password" name="password">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">Gender</label>
                          <select required class="form-select form-select-sm" id="exampleFormControlSelect3" name="gender">
                            <option value="1" <?php echo e($gender==1?'selected':''); ?>>Male</option>
                            <option value="2" <?php echo e($gender==2?'selected':''); ?>>Female</option>
                            <option value="3" <?php echo e($gender==3?'selected':''); ?>>Other</option>
                          </select>
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">Country</label>
                          <select required class="form-select form-select-sm" id="country" name="country_id">
                            <option value="">Select Country</option>  
                            <?php if($country): ?>
                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($country->country_id); ?>" <?php echo e($country_id==$country->country_id?'selected':''); ?>><?php echo e($country->country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                          </select>
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">State</label>
                          <select required class="form-select form-select-sm" id="state" name="state_id">
                            <option>Select State</option>
                            <?php if($state): ?>
                            <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($states->state_id); ?>" <?php echo e($state_id==$states->state_id?'selected':''); ?>><?php echo e($states->state_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </select>
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">City</label>
                          <select required class="form-select form-select-sm" id="city" name="city_id">
                            <option>Select City</option>
                            <?php if($city): ?>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cities->city_id); ?>" <?php echo e($city_id==$cities->city_id?'selected':''); ?>><?php echo e($cities->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </select>
                        </div>
                        <div class="form-group col-md-6">
                          <label for="exampleInputEmail1">Profile Image</label>
                          <input type="file" class="form-control form-control-sm" id="exampleInputEmail1" name="profile_image" accept="image/png, image/gif, image/jpeg">
                        </div>
                      </div>
                      <input type="hidden" name="user_time" value="" id="user_timezone">
                      <button type="submit" class="btn btn-primary me-2">Submit</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
        </div>
        <!-- main-panel ends -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>
        <script>
          document.addEventListener("DOMContentLoaded", function () {
              const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
              document.getElementById("user_timezone").value = userTimezone;
          });
          $(document).ready(function () {
            $(document).on('change', '#country', function () {
              var cid = this.value;   //let cid = $(this).val(); we cal also write this.
              $.ajax({
                url: "<?php echo e(url('/admin/getstate')); ?>",
                type: "POST",
                datatype: "json",
                data: {
                  country_id: cid,
                  '_token':'<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                  $('#state').html('<option value="">Select State</option>');
                  $.each(result.state, function(key, value) {
                    $('#state').append('<option value="' +value.state_id+ '">' +value.state_name+ '</option>');
                  });
                },
                errror: function(xhr) {
                    console.log(xhr.responseText);
                  }
                });
            });

            $('#state').change(function () {
              var sid = this.value;
              $.ajax({
                url: "<?php echo e(url('/admin/getcity')); ?>",
                type: "POST",
                datatype: "json",
                data: {
                  state_id: sid,
                  '_token':'<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                  console.log(result);
                  $('#city').html('<option value="">Select City</option>');
                  $.each(result.city, function(key, value) {
                    $('#city').append('<option value="' +value.city_id+ '">' +value.city_name+ '</option>')
                  });
                },
                errror: function(xhr) {
                    console.log(xhr.responseText);
                  }
              });
            });
          });
        </script>
        <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coachsparkle\resources\views/admin/add_user.blade.php ENDPATH**/ ?>